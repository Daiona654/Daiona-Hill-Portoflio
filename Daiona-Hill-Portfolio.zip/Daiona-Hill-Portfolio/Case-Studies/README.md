# Case Studies

This folder contains business and finance case studies and written analyses.

## Project 4 — Business Case Study
**Description:** A case study analyzing a business situation and explaining possible decisions or outcomes.

**Skills demonstrated:** Critical thinking, business analysis, problem-solving, and written communication.

## Project 5 — Finance Case Study
**Description:** A finance-focused analysis demonstrating my ability to interpret financial information and communicate my findings.

**Skills demonstrated:** Financial analysis, research, critical thinking, and professional writing.
