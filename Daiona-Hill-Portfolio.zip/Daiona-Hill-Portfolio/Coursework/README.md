# Coursework

This folder contains selected original coursework that demonstrates my academic growth, communication, problem-solving, and business knowledge.

## Project 1 — Business Computer Applications Project
**Description:** A class project demonstrating my ability to use business technology and organize information professionally.

**Skills demonstrated:** Computer applications, organization, communication, and professional presentation.
