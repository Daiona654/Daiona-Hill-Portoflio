# Excel Projects

This folder contains spreadsheet and data-analysis projects completed during the semester.

## Project 2 — Excel Financial Analysis
**Description:** An Excel-based project demonstrating how I organize data, use spreadsheet tools, and analyze business or financial information.

**Skills demonstrated:** Microsoft Excel, data organization, formulas, financial analysis, and attention to detail.
