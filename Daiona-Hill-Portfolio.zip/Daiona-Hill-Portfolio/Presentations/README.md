# Presentations

This folder contains presentations I created for my college courses.

## Project 3 — Business Presentation
**Description:** A presentation created to communicate course information clearly and professionally.

**Skills demonstrated:** Presentation design, research, organization, written communication, and public speaking.
